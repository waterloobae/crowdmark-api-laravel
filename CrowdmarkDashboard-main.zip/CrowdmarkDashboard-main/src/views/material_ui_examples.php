  <h2 class="md-typescale-large">Check out these controls in a form!</h2>
  <h3 class="md-typescale-medium">Filter Chip</h3>
    <md-filter-chip label="2024 Euclid A">
    </md-filter-chip>
    <md-filter-chip label="2024 Euclid b">
    </md-filter-chip>
      <md-divider></md-divider>
  <h3 class="md-typescale-medium">Check box</h3>
  <label><md-checkbox></md-checkbox> 2024 Euclid B</label>
  <label><md-checkbox></md-checkbox> 2024 Euclid C</label>            
  <h2 class="md-typescale-large">Check out these buttons in a form!</h2>
    <md-fab label="Refresh" aria-label="Refresh">
      <md-icon slot="icon">refresh</md-icon>
    </md-fab>

    <md-fab label="Remove" aria-label="Remove">
      <md-icon slot="icon">delete</md-icon>
    </md-fab>

    <md-fab label="Generate" aria-label="Generate">
      <md-icon slot="icon">start</md-icon>
    </md-fab>
