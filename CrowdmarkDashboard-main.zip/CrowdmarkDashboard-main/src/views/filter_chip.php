    <div class="md-chip-container">
    <md-filter-chip label="{_LABEL}" \>
    </md-filter-chip>
    </div>
